#include<iostream>
using namespace std;
class shape{
	int width, lenght;
public:
	shape() :width(0), lenght(0){}
	virtual	int getarea() = 0;

};
class triangle :public shape{
	int widht, lenght;
public:
	triangle(int w, int l){ widht=w; lenght = l; }
	int getarea()
	{
		return (lenght*widht);
	}
};
class rectangle:public triangle{
	int lenght, widht;
public:
	rectangle(int w, int l) :triangle(w, l){ lenght = l; widht = w; }
	int getarea()
	{
		return (lenght*widht);
	}
	
};
class circle:public shape{
	float diameter;
public:
	circle(float d):diameter(d){}
	int getarea()
	{
		return diameter;
	}
};
int main()
{
	rectangle r(3, 2);
	triangle t(3, 2);
	circle c(3.2);
	shape *s[3];
	*s[0] = r;
	*s[1] = t;
	*s[2] = r;

	system("pause");
}
