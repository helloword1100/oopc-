#include <iostream>
using namespace std;
class test1{
public:
	virtual void f1()
	{
		cout << "hell";
	}
};
class test2:public test1{
public:
	void f1()
	{
		cout << "hellloo";
	}
};
int main()
{
	test1 *ptr, obj1;
	test2 obj2;
	ptr = new test1;
	ptr->f1();
	cout << endl;
	ptr =&obj2;
	ptr->f1();
	system("pause");
	return 0;
}
