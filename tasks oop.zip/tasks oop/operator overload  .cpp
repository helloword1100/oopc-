#include <iostream>
using namespace std;
class test{
	int x;
public:
	test()
	{
		x = 0;
	}
	test(int u)
	{
		x = u;
	}
	friend  test operator +(const test &obj1, const test &obj2);
	friend istream &operator >>(istream &input, test &obj);
	friend ostream &operator <<(ostream &output, test &obj);

};
test operator +(const test &obj1, const test &obj2)
{
	return obj1.x + obj2.x;
}
 istream &operator >>(istream &input, test &obj)
{
	input >> obj.x;
	return input;
}
 ostream &operator <<(ostream &output, test &obj)
 {
	 output << obj.x;
	 return output;
 }
int main()
{
	test t1,t2,sum;
	cout << "enter 1st value \n";
	cin >> t1;
	cout << "enter 2nd value \n";
	cin >> t2;
	sum = t1 + t2;
	cout << "sum : "<<sum;
	system("pause");
	return 0;
}