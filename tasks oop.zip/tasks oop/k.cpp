/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class a{
  int x;
  public:
  a(int y):x(y){}
  int getx(){return x;}
  
};
class b{
   a obj;
   public:
   b(int z):obj(z){}
   
   b(b &obj1):obj(obj1.obj)
   {
       
   }
   void overload(int x)
   {
       obj=x;
       cout<<x;
   }
  friend ostream operator <<(ostream &o,b &obj1);
   void display()
   {
       cout<<obj.getx();
   }
   void operator +(b &obj3)
   {
       int sum=obj.getx()+obj3.obj.getx();
       cout<<sum;
   }

};
ostream operator <<(ostream& o,b &obj1)
 {
       o<<obj1.obj.getx();
       return o;
}
int main()
{
   b obj1(3),obj2(3);
   obj1+obj2;
   obj1.overload(3);
   //
   b obj3(4),obj4=obj3;
   obj4.display();
    return 0;
}

