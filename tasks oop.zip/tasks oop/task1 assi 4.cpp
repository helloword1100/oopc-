 #include <iostream>
  using namespace std;
  class person{
  	private:
  		public:
  			person()
  			{
  				
			  }
  	person(int x)
  			{
  				cout<<"person::person(int) is called..\n";
			  }
  };
  class faculty:virtual public person{
  	private:
  		public:
  			faculty(int x):person(x)
  			{
  				cout<<"faculty::faculty(int) is called..\n";
			  }
  };
  class student:virtual public person{
  	private:
  		public:
  			student(int x):person(x)
  			{
  				cout<<"student::student(int) is called...\n";
			  }
  };
  class ta: public faculty ,public student{
  	private:
  		public:
  			ta(int x):faculty(x),student(x),person(x)
  			{
  				cout<<"ta::ta(int) is called...\n";
			  }
  };
  int main()
  {
  	ta t1(30);
  }
