#include<iostream>
using namespace std;
//multiple inheritance
class person{
	int age;
public:
	person(int a)
	{
		age = a;
		cout << "person";
	}
	void display()
	{
		cout << "person";
	}
virtual	~person()
	{
		cout << "hello";
	}
};
class faculty :virtual public person{
public:
	faculty(int a) :person(a)
	{
		cout << "faculty";
	}
	void display()
	{
		cout << "faculty";
	}
};
class student :virtual public person{
public:
	student(int a) :person(a)
	{
		cout << "student";
	}
	void display()
	{
		cout << "student ";
	}
};
class ta : public faculty,public student{
public:
	ta(int a) :faculty(a), student(a) ,person(a)
	{
		cout << "ta";
	}
	void display() 
	{
	}
};
int main() {
	ta t(4);
	t.display();
	system("pause");
}

