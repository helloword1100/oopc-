#include<iostream>
using namespace std;
class base{
public:
	int x, y;

	base() :x(0), y(0){		cout << "\nbase() called\n";}
	base(int a,int b) :x(a), y(b){cout << "\nbase() called\n";}
	base(const base  &obj)
	{
		cout << "\nbase copy called\n";
		x = obj.x;
		y = obj.y;
	}
 void display(void)
	{
		cout<<"\nx="<<x<<"y="<<y<<"\n";
	}

};
class derive :public base{
protected:
public:
	int z;
	derive(int a,int b,int c) :base(a,b){cout << "\nderived(a,b,c) called\n";z=c;}
	derive(const derive  & d): base::base(d),z(d.z){}
 void display(void)
	{	base::display();
		cout<<"\nz="<<z;
	}

};
int main(void)
{

	derive d1(1,2,3);
	derive d2(1,2,3);
d2=d1;
	d2.display();
	system("pause");
	return 0;
}
