#include <iostream>
using namespace std;
class test1{
public:
	void f1()
	{
		cout << "hell";
	}
	virtual void f2()
	{
		cout << "great";
	}
	virtual void f3()
	{

	}
	
};
class test2: public test1{
public:
	void f1()
	{
		cout << "hellloo";
	}
	void f2()
	{
		cout << "world";
	}
	void f3(int f)
	{
		cout << "paramert\n";
	}
};
int main()
{
	test1 *ptr;
	test2 obj;
	ptr = &obj;
	ptr->f1();
	ptr->f2();
	ptr->f3();
	ptr->f3(4);
	system("pause");
	return 0;
}
