#include <iostream>
using namespace std;
class test{
	int n;
public:
	test()
	{

	}
	test(int i)
	{
		n = i;
	}
	void show()
	{
		cout << n;
	}
	friend test operator +(const test &obj1, const test &obj2);
};
test operator +(const test &obj1,const test &obj2)
{
	return obj1.n + obj2.n;
}

int main()
{
	test obj1(8),sum;
	test obj2(2);
	sum = obj1 + obj2;
	sum.show();
	system("pause");
	return 0;
}