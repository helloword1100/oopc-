#include <iostream>
using namespace std;
class test{

};
int main()
{
	system("pause");
	return 0;
}