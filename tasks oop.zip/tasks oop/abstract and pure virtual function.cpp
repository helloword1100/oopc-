#include <iostream>
using namespace std;
class test1{
	
public:
	 void f1()
	{

	}
virtual	 void display() 
	 {
	 	cout<<"dd";
	 }
};
class test2: public test1{
public:
	void display()
	{
		cout << "hello display \n";
	}
	
};
int main()
{
	test1 *ptr;
	test2 obj;
	ptr = &obj;
	ptr->display();
	system("pause");
	return 0;
}
