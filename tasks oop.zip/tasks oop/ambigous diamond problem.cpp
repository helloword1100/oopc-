#include <iostream>
using namespace std;
class test1{

public:
	void f1()
	{

	}
	 void display()
	{
		cout << "hello ";
	}
};
class test2: public test1{
public:
	void display()
	{
		cout << "hello display \n";
	}
	
};
class test3:public test1,public test2{
public:

};
int main()
{
	test1 *obj1;
	test2 obj2;
	test3 obj3;
	obj3.display();//ambigous 
	system("pause");
	return 0;
}
