#include <iostream>
using namespace std;
class test1{

public:
	void f1()
	{
		cout << "hello f1";
	}
};
class test2:public test1{
public:
	void f2()
	{
		cout << "hello f2";
	}
};
class test22:public test1{
public:
	void f3()
	{
		cout << "hello f1";
	}
};
class test3:virtual public test2,public test22{
public:
	void f4()
	{
		cout << "hello f3";
	}
};
int main()
{
	test3 obj1;
	obj1.f1();
	system("pause");
	return 0;
}
