#include<iostream>
#include<string.h>
using namespace std;
class person{
	char *name;
	public:
	virtual void set()
		{char nam[100];
		cout<<"name "<<" ";
			cin>>nam;
			int size=0;
			for(int i=0;nam[i]!='\0';i++)
			{
				size++;
			}
			name=new char [size];
			for(int i=0;i<=size;i++)
			{
				name[i]=nam[i];
			}
		}
	virtual	void display()
		{
			
			cout<<name;
		}
	virtual	~person()
		{
			delete [] name;
			cout<<"dest person class ";
		}
};
class employee:public person{
int org;
	public:
		virtual void set()
		{
			person::set();
			cout<<"org ";
			cin>>org;
			
		}
		virtual void display()
		{
		person::display();
		cout<<org<<endl;
		}
	virtual	~employee()
		{
			cout<<"destructor employeee";
		}
};
class manager:public employee{
	int subs;
	public:
		void set()
		{employee::set();
			
		cin>>subs;
		}
		void display()
		{employee::display();
			cout<<subs<<" ";
		}
		~manager()
		{
			cout<<"manager destructor ";
		}
};
int main()
{
	person *p;
	employee e;
	manager m;
	p=&e;
	p->set();
	p->display();
	delete p;
	p=&m;
	p->set();
	p->display();
	delete p;

}
