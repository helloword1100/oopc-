/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class a{
    char *str='\0';
    public:
    
    a(char *s)
    {
    	 int size=0;
        for(int i=0;s[i]!='\0';i++)
        {
            size++;
            
        }
        str=new char[size];
        for(int i=0;i<=size;i++)
        {
            str[i]=s[i];
        }
    }
    void check(char c)
    {
    	int size=0;
    	 for(int i=0;str[i]!='\0';i++)
        {
            size++;
            
        }
    	
        for(int i=0;i<=size;i++)
        {
            
        if(str[i]==c)
        {
            cout<<"yes";
            break;
        }
        else
        {
            cout<<"no";
        }
        }
    }
   void get()
    {
        cout<<str;
    }
};
int main()
{
    char s[3]={'e','d'};
    a obj(s);
    obj.get();
    char o={'e'};
    obj.check(o);

    return 0;
}

